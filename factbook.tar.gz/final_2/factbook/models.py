from __future__ import unicode_literals
from ckeditor.fields import RichTextField
from ckeditor_uploader.fields import RichTextUploadingField
from django.db import models
from django.utils import timezone
from Info.models import *
from django.contrib.auth.models import User


class Post(models.Model):
	company = models.ForeignKey(company_name)
	CATE_CHOICES = (
		('Corporate Overview', (
				('business scope', 'Business Scope'),
				('history', 'History'),
				('change in capital', 'Change in Capital'),
				('share with voting right', 'Share with Voting Right'),
				('dividend', 'Dividend'),
			)
		),
		('Business and Operation', (
					('industry overview', 'Industry Overview'),
					('performance by segment', 'Performance by segment'),
					('cost of product', 'Cost of Product'),
					('average sell price', 'Average Sell Price'),
					('production and utilization', 'Production and Utilization'),
			)
		),
		('Risk Analysis', (
				('liquidity risk', 'Liquidity Risk'),
				('f/x exposure', 'F/X Exposure'),
				('interest risk', 'Interest Risk'),
				('credit risk', 'Credit Risk'),
				('other risk', 'Other Risk'),
			)
		),
		('Financials', (
			('income statement', 'Income Statement'),
			('balance sheet', 'Balance Sheet'),
			('cash flow', 'Cash Flow'),
			)
		),
		('Governance', (
			('ownership', 'Ownership'),
			('bod/management', 'BOD/Management'),
			('management', 'Management'),
			)
		),
	)
	category = models.CharField(max_length = 30, choices=CATE_CHOICES,default='business scope')
	text = RichTextUploadingField()
	created_date = models.DateTimeField(default=timezone.now)
	published_date = models.DateTimeField(blank=True, null=True)

	def publish(self):
		self.published_date = timezone.now()
		self.save()

class document(models.Model):
	company = models.ForeignKey(company_name)
	fact_document = models.FileField(null = True)
	location = models.CharField(max_length = 250)
	price = models.DecimalField(decimal_places = 2, max_digits=7)

class Purchase(models.Model):
	resource = models.ForeignKey(document)
	purchaser = models.ForeignKey(User)
	purchased_at = models.DateTimeField(auto_now_add=True)
	tx = models.CharField(max_length=250)

# Create your models here.
