from django import forms

class PostSearchForm(forms.Form):
	search_word = forms.CharField(
		max_length=100,
		widget=forms.TextInput(
			attrs={
				'placeholder' : '  Type In Company Name or Ticker',
				'required': 'True',
			}
		)
	)

class fact_busi(forms.Form):
	search = forms.CharField(max_length=100)

class fact_hist(forms.Form):
	search = forms.CharField(max_length=100)

class fact_capi(forms.Form):
	search = forms.CharField(max_length=100)

class fact_righ(forms.Form):
	search = forms.CharField(max_length=100)

class fact_divi(forms.Form):
	search = forms.CharField(max_length=100)

class fact_liqu(forms.Form):
	search = forms.CharField(max_length=100)

class fact_expo(forms.Form):
	search = forms.CharField(max_length=100)

class fact_inte(forms.Form):
	search = forms.CharField(max_length=100)

class fact_cred(forms.Form):
	search = forms.CharField(max_length=100)

class fact_owne(forms.Form):
	search = forms.CharField(max_length=100)

class fact_bod(forms.Form):
	search = forms.CharField(max_length=100)

class fact_mana(forms.Form):
	search = forms.CharField(max_length=100)

class fact_indu(forms.Form):
	search = forms.CharField(max_length=100)

class fact_perf(forms.Form):
	search = forms.CharField(max_length=100)

class fact_cost(forms.Form):
	search = forms.CharField(max_length=100)

class fact_aver(forms.Form):
	search = forms.CharField(max_length=100)

class fact_prod(forms.Form):
	search = forms.CharField(max_length=100)

class fact_inco(forms.Form):
	search = forms.CharField(max_length=100)

class fact_bala(forms.Form):
	search = forms.CharField(max_length=100)

class fact_cash(forms.Form):
	search = forms.CharField(max_length=100)

class fact_othe(forms.Form):
	search = forms.CharField(max_length=100)

