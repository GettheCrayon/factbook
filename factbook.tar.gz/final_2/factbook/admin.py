from django.contrib import admin
from .models import Post, document

#class companyInline(admin.StackedInline):
	#model = Post

class PostAdmin(admin.ModelAdmin):
	#inlines = [companyInline]
	list_display = ('company','category','created_date', 'id')

admin.site.register(Post,PostAdmin)
admin.site.register(document)

# Register your models here.




