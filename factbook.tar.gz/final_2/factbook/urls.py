from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.factbook_list.as_view(), name='factbook_list'),
    url(r'^more/(?P<pk>\d+)/', views.factbook_more.as_view(), name='factbook_more'),
    url(r'^detail/', views.factbook_detail.as_view(), name='factbook_detail'),

    url(r'^download_page/$', views.factbook_download.as_view(), name = 'down'),
]
