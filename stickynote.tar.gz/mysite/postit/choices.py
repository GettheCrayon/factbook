COLOR_CHOICES = (
    ('#E9E74A', 'yellow'),
    ('#EE5E9F', 'pink'),
    ('#2F98ED', 'blue'),
    ('#3ED667', 'green'),
)
STATUS_CHOICES = (
    ('to-do', 'To Do'),
    ('doing', 'Doing'),
    ('done', 'Done'),
)