from django.contrib import admin
from .models import PostIt, UserProfile

admin.site.register(PostIt)
admin.site.register(UserProfile)
