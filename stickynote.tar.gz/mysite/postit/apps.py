from django.apps import AppConfig


class PostitConfig(AppConfig):
    name = 'postit'
