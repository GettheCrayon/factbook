from fileupload.models import Picture
from django.contrib import admin

admin.site.register(Picture)