Generic programming library for Python
======================================

Generic is trying to be simple and easy-to-use programming library that
provides a set of tools for generic programming with Python.

Documentation is at http://packages.python.org/generic/.
Its development takes place at http://github.com/andreypopp/generic.


Changes
=======

0.3
---

- Event management with event inheritance support.

0.2
---

- Methods with multidispatch by object type and positional arguments.
- Override multifunctions with ``override`` method.

0.1
---

- Registry with simple and type axes.
- Functions with multidispatch by positional arguments.


