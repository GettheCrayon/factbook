VERSION = (5, 3, 0)
__version__ = '.'.join(map(str, VERSION))
