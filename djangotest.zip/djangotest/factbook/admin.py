from django.contrib import admin
from .models import Post
from factbook.models import comp_name

#class companyInline(admin.StackedInline):
	#model = Post

class PostAdmin(admin.ModelAdmin):
	#inlines = [companyInline]
	list_display = ('title','company','created_date')

admin.site.register(Post,PostAdmin)

# Register your models here.




