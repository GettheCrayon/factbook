from django.shortcuts import render
from Disclosure.models import disclosure_index
from django.views.generic.edit import FormView
from django.db.models import Q
from .forms import PostSearchForm
from .models import Post

# Create your views here.

class factbook_list(FormView):
	model = Post
	form_class = PostSearchForm
	template_name = 'factbook/factbook.html'

	def form_valid(self, form):
		schWord = '%s' % self.request.POST['search_word']
		post_list = disclosure_index.objects.filter(Q(company__title__icontains=schWord)).distinct()

		context = {}
		context['form'] = form
		context['search_term'] = schWord
		context['object_list'] = post_list

		return render(self.request,'search.html', context)
