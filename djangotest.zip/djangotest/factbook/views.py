from django.shortcuts import render
from django.views.generic import ListView

# Create your views here.
def factbook_list(request):
        return render(request, 'factbook/factbook.html', {})

#class factbook_list(ListView):
#	template_name = 'factbook/factbook.html'


