from __future__ import unicode_literals
from ckeditor_uploader.widgets import CKEditorUploadingWidget
from django import forms
from .models import Post


class MyForm(forms.ModelForm):
	title = forms.CharField(required=True)
	text = forms.CharField(widget=CKEditorUploadingWidget())

	class Meta:
	   model = Post
	   fields = ('title', 'text')


class LoginForm(forms.Form):
        f_user_id = forms.CharField(label='User_ID', max_length=30)
        f_user_name = forms.CharField(label='User_name', max_length=30)
