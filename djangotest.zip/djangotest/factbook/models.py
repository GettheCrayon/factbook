from __future__ import unicode_literals
from ckeditor.fields import RichTextField
from ckeditor_uploader.fields import RichTextUploadingField
from django.db import models
from django.utils import timezone
from Info.models import *
from django.contrib.auth.models import User

class comp_name(models.Model):
	name = models.ForeignKey(company_name)
	
	def __str__(self):
		return self.title

class Post(models.Model):
	author = models.ForeignKey(User, null=True)
	company = models.ForeignKey(company_name)
	title = models.CharField(max_length=200)
	text = RichTextUploadingField()
	created_date = models.DateTimeField(default=timezone.now)
	published_date = models.DateTimeField(blank=True, null=True)

	def publish(self):
		self.published_date = timezone.now()
		self.save()

	def __str__(self):
		return self.title


class Userlist(models.Model):
	user_id = models.CharField(max_length=30)
	user_name = models.CharField(max_length=30)
# Create your models here.
