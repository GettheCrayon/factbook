from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.factbook_list, name='factbook_list'),
    #url(r'^issue_analysis/', views.issue_analysis_list, name='issue_analysis_list'),
    #url(r'^disclosures/', views.disclosures_list, name='disclosures_list'),
    #url(r'^analyst_report/', views.analyst_report_list, name='analyst_report_list'),
    #url(r'^community/', views.community_list, name='community_list'),
   
]
