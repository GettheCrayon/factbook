from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm, AdminPasswordChangeForm

class UserCreateForm(UserCreationForm):
	company = forms.CharField(required=True, max_length = 30,
				widget=forms.TextInput(attrs={'placeholder' : '   Company Name'})
	)
	name = forms.CharField(required=True, max_length = 30,
				widget=forms.TextInput(attrs={'placeholder' : '   Your Name'})
	)
	
	class Meta:
		model = User
		fields = ("username", "password1", "password2", "company", "name")
		
	def save(self, commit=True):
		user = super(UserCreateForm, self).save(commit=False)
		user.company = self.cleaned_data["company"]
		user.name = self.cleaned_data["name"]
		if commit:
			user.save()
		return user
	
	def __init__(self, *args, **kwargs):
		super(UserCreateForm, self).__init__(*args, **kwargs)

		self.fields['username'].widget.attrs['placeholder'] = "   ID(Email)"
		self.fields['password1'].widget.attrs['placeholder'] = "   Please Enter Your Password"
		self.fields['password2'].widget.attrs['placeholder'] = "   Please Enter Your Password again"
		#self.fileds['company'].widget.attrs['placeholder'] = " Company Name"
		#self.fileds['name'].widget.attrs['placeholder'] = " Your Name"

class LoginForm(AuthenticationForm):
	username = forms.CharField(
		max_length=100,
		widget=forms.TextInput(
			attrs={
				'placeholder' : '  ID',
				'required': 'True',
			}
		)
	)

	password = forms.CharField(
		widget=forms.PasswordInput(
			attrs={
				'placeholder': '  PASSWORD',
				'required': 'True',
			}
		)
	)

class PasswordChangeForm(AdminPasswordChangeForm):

	password1 = forms.CharField(
		widget=forms.PasswordInput(
			attrs={
				'placeholder': '  NEW PASSWORD',
				'required': 'True',
			}
		)
	)
	password2 = forms.CharField(
		widget=forms.PasswordInput(
			attrs={
				'placeholder': '  NEW PASSWORD AGAIN',
				'required': 'True',
			}
		)
	)
