from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm, AdminPasswordChangeForm

class UserCreateForm(UserCreationForm):
	company = forms.CharField(required=True, max_length = 30,
				widget=forms.TextInput(attrs={'placeholder' : '   Company Name'})
	)
	name = forms.CharField(required=True, max_length = 30,
				widget=forms.TextInput(attrs={'placeholder' : '   Your Name'})
	)
	
	class Meta:
		model = User
		fields = ("username", "password1", "password2", "company", "name")
		
	def save(self, commit=True):
		user = super(UserCreateForm, self).save(commit=False)
		user.company = self.cleaned_data["company"]
		user.name = self.cleaned_data["name"]
		if commit:
			user.save()
		return user
	
	def __init__(self, *args, **kwargs):
		super(UserCreateForm, self).__init__(*args, **kwargs)

		self.fields['username'].widget.attrs['placeholder'] = "   ID(Email)"
		self.fields['password1'].widget.attrs['placeholder'] = "   Please Enter Your Password"
		self.fields['password2'].widget.attrs['placeholder'] = "   Please Enter Your Password again"
		
class LoginForm(AuthenticationForm):
	username = forms.CharField(
		max_length=100,
		widget=forms.TextInput(
			attrs={
				'placeholder' : '  ID',
				'required': 'True',
			}
		)
	)

	password = forms.CharField(
		widget=forms.PasswordInput(
			attrs={
				'placeholder': '  PASSWORD',
				'required': 'True',
			}
		)
	)

class PostSearchForm(forms.Form):
	search_word = forms.CharField(
		max_length=100,
		widget=forms.TextInput(
			attrs={
				'placeholder' : '  Type In Company Name or Ticker',
				'required': 'True',
			}
		)
	)

class PostSearchind(forms.Form):
	search_ind_result = forms.CharField(max_length=100)
	
class PostSearchdis(forms.Form):
	search_dis_result = forms.CharField(max_length=100)

class PostSearchana(forms.Form):
	search_ana_result = forms.CharField(max_length=100)

class PasswordChangeForm(AdminPasswordChangeForm):

	password1 = forms.CharField(
		widget=forms.PasswordInput(
			attrs={
				'placeholder': '  NEW PASSWORD',
				'required': 'True',
			}
		)
	)
	password2 = forms.CharField(
		widget=forms.PasswordInput(
			attrs={
				'placeholder': '  NEW PASSWORD AGAIN',
				'required': 'True',
			}
		)
	)
