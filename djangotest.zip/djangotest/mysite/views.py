from django.views.generic.base import TemplateView
from .forms import UserCreateForm
from django.views.generic.edit import CreateView, FormView
from django.core.urlresolvers import reverse_lazy

from .forms import PostSearchForm, PostSearchind, PostSearchdis, PostSearchana
from django.db.models import Q
from django.shortcuts import render

from Issue.models import Issue_index
from Disclosure.models import disclosure_index
from Analyst.models import analyst_index
from factbook.models import Post
from django.shortcuts import redirect

class SearchFormView(FormView):
	form_class = PostSearchForm
	template_name = 'home.html'
	
	def form_valid(self, form):	
		schWord = '%s' % self.request.POST['search_word']
		ind_post_list = Issue_index.objects.filter(Q(company__title__icontains=schWord)).distinct()[:6]
		dis_post_list = disclosure_index.objects.filter(Q(company__title__icontains=schWord)).distinct()[:6]
		ana_post_list = analyst_index.objects.filter(Q(company__title__icontains=schWord)).distinct()[:6]
		context = {}
		context['form'] = form
		context['search_term'] = schWord
		context['ind_object_list'] = ind_post_list
		context['dis_object_list'] = dis_post_list
		context['ana_object_list'] = ana_post_list

		return render(self.request,'search.html', context)

class SearchResultForm(FormView):
	form_class = PostSearchForm
	template_name = 'search.html'

	def form_redirect(request):
		if request.method == 'POST':
			if "sub_ind" in request.POST:
				form = PostSearchind(request.POST)
				if form.is_valid():
					search_result = request.POST['search_ind_result']
					sch_ind = Issue_index.objects.filter(company__title = search_result)
					context = {}
					context['sch_term'] = search_result
					context['sch_ind'] = sch_ind
					return render(request,'Issue/Industry_Analysis_more.html', context)
				else:
					form = PostSearchind()
			elif "sub_dis" in request.POST:
				form = PostSearchdis(request.POST)
				if form.is_valid():
					print('aaaaa')
					search_result = request.POST['search_dis_result']
					sch_dis = disclosure_index.objects.filter(company__title = search_result)
					context = {}
					context['sch_term'] = search_result
					context['sch_dis'] = sch_dis
					return render(request,'Disclosure/Disclosure_more.html',context)
				else:
					form = PostSearchdis()
		#if request.method == "GET":
			#if request.POST.get('result_ind'):
					
					#return redirect('Issue/Industry_Analysis_more.html', pk=post.pk)
			#elif request.POST['result_dis']:
					
					#return redirect('Disclosure/Disclosure_more.html', pk=post.pk)
			#elif 'result_ana' in request.GET and request.GET['search_ana_result']:
			#	search_result = request.GET['search_ana_result']
			#	sch_ana = analyst_index.objects.filter(company__title = search_result)
			#	context = {}
			#	context['sch_term'] = search_result
			#	context['sch_ana'] = sch_ana
			#	return render(request,'Analyst/Analyst_more.html', context)
					#return redirect('Analyst/Analyst_more.html', pk=post.pk)
		
	def form_valid(self, form):	
		schWord = '%s' % self.request.POST['search_word']
		ind_post_list = Issue_index.objects.filter(Q(company__title__icontains=schWord)).distinct()[:6]
		dis_post_list = disclosure_index.objects.filter(Q(company__title__icontains=schWord)).distinct()[:6]
		ana_post_list = analyst_index.objects.filter(Q(company__title__icontains=schWord)).distinct()[:6]
		context = {}
		context['form'] = form
		context['search_term'] = schWord
		context['ind_object_list'] = ind_post_list
		context['dis_object_list'] = dis_post_list
		context['ana_object_list'] = ana_post_list

		return render(self.request,'search.html', context)

	
#--- User Creation

class UserCreateView(CreateView):
	template_name = 'registration/register.html'
	form_class = UserCreateForm
	success_url = reverse_lazy('register_done')

class UserCreateDoneTV(TemplateView):
	template_name = 'registration/register_done.html'
