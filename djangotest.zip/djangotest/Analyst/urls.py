from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.analyst_home.as_view(), name='Analyst_home'),
    url(r'^Analyst_more/', views.analyst_more.as_view(), name='more'),
]
