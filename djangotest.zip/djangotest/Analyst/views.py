from django.shortcuts import render
from django.views.generic import ListView
from Analyst.models import analyst_index

# Create your views here.

class analyst_home(ListView):
	model = analyst_index
	template_name = 'Analyst/Analyst_home.html'

	def get_context_data(self, **kwargs):
		context = super(analyst_home, self).get_context_data(**kwargs)
		context['samsung'] = analyst_index.objects.filter(company__title = 'samsung')
		
		return context
