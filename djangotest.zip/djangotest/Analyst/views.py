from django.shortcuts import render
from django.views.generic import ListView
from Disclosure.models import disclosure_index
from Analyst.models import analyst_index
from django.views.generic.edit import FormView
from django.db.models import Q
from .forms import PostSearchForm


# Create your views here.

class analyst_home(FormView):
	model = analyst_index
	form_class = PostSearchForm
	template_name = 'Analyst/Analyst_home.html'

	def get_context_data(self, **kwargs):
		context = super(analyst_home, self).get_context_data(**kwargs)
		context['samsung'] = analyst_index.objects.filter(company__title = 'samsung')
		
		return context

	def form_valid(self, form):
		schWord = '%s' % self.request.POST['search_word']
		post_list = disclosure_index.objects.filter(Q(company__title__icontains=schWord)).distinct()

		context = {}
		context['form'] = form
		context['search_term'] = schWord
		context['object_list'] = post_list

		return render(self.request,'search.html', context)

class analyst_more(FormView):
	model = analyst_index
	form_class = PostSearchForm
	template_name = 'Analyst/Analyst_more.html'
	
	def get_context_data(self, **kwargs):
		context = super(disclosure_more, self).get_context_data(**kwargs)
		context['all_analyst'] = analyst_index.objects.all()
		
		return context

	def form_valid(self, form):
		schWord = '%s' % self.request.POST['search_word']
		post_list = disclosure_index.objects.filter(Q(company__title__icontains=schWord)).distinct()

		context = {}
		context['form'] = form
		context['search_term'] = schWord
		context['object_list'] = post_list

		return render(self.request,'search.html', context)
