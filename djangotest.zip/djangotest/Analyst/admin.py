from django.contrib import admin
from .models import analyst_index

class PostAdmin(admin.ModelAdmin):

	list_display = ('title','company','created_date')

admin.site.register(analyst_index,PostAdmin)

# Register your models here.




