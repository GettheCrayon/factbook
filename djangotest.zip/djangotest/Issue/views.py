from django.shortcuts import render
from django.views.generic import ListView, DetailView
from Info.models import *
from Issue.models import Issue_index

# Create your views here.

#--- TemplateView

class Issue_Main(ListView):
	model = Issue_index
	template_name = 'Issue/Industry_Analysis.html'
	
	def get_context_data(self, **kwargs):
		context = super(Issue_Main, self).get_context_data(**kwargs)
		context['industry'] = Issue_index.objects.all()
		
		return context

class Issue_Consumer(ListView):
	model = Issue_index
	template_name = 'Issue/Industry_Consumer.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Consumer, self).get_context_data(**kwargs)
		context['con_industry'] = Issue_index.objects.filter(company__second_industry_name__parent__first_name = 'Consumer')
		
		return context

class Issue_Apparel(ListView):
	model = Issue_index
	template_name = 'Issue/Consumer/Industry_Apparel.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Apparel, self).get_context_data(**kwargs)
		context['app_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Apparel')
		
		return context

class Issue_Auto(ListView):
	model = Issue_index
	template_name = 'Issue/Consumer/Industry_Auto.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Auto, self).get_context_data(**kwargs)
		context['aut_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Auto')
		
		return context

class Issue_Cosmetics(ListView):
	model = Issue_index
	template_name = 'Issue/Consumer/Industry_Cosmetics.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Cosmetics, self).get_context_data(**kwargs)
		context['cos_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Cosmetics')
		
		return context

class Issue_Distribution(ListView):
	model = Issue_index
	template_name = 'Issue/Consumer/Industry_Distribution.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Distribution, self).get_context_data(**kwargs)
		context['dis_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Distribution')
		
		return context

class Issue_Entertainment(ListView):
	model = Issue_index
	template_name = 'Issue/Consumer/Industry_Entertainment.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Entertainment, self).get_context_data(**kwargs)
		context['ent_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Entertainment')
		
		return context

class Issue_Education_Service(ListView):
	model = Issue_index
	template_name = 'Issue/Consumer/Industry_Education_Service.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Education_Service, self).get_context_data(**kwargs)
		context['edu_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Education_Service')
		
		return context

class Issue_Food_Beverage(ListView):
	model = Issue_index
	template_name = 'Issue/Consumer/Industry_Food&Beverage.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Food_Beverage, self).get_context_data(**kwargs)
		context['foo_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Food_Beverage')
		
		return context

class Issue_Game(ListView):
	model = Issue_index
	template_name = 'Issue/Consumer/Industry_Game.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Game, self).get_context_data(**kwargs)
		context['gam_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Game')
		
		return context

class Issue_Media(ListView):
	model = Issue_index
	template_name = 'Issue/Consumer/Industry_Media.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Media, self).get_context_data(**kwargs)
		context['med_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Media')
		
		return context

class Issue_Energy(ListView):
	model = Issue_index
	template_name = 'Issue/Industry_Energy.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Energy, self).get_context_data(**kwargs)
		context['ene_industry'] = Issue_index.objects.filter(company__second_industry_name__parent__first_name = 'Energy')
		
		return context

class Issue_Oil_Gas(ListView):
	model = Issue_index
	template_name = 'Issue/Energy/Industry_Oil_Gas.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Oil_Gas, self).get_context_data(**kwargs)
		context['oil_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Oil_Gas')
		
		return context

class Issue_Petrochem(ListView):
	model = Issue_index
	template_name = 'Issue/Energy/Industry_Petrochem.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Petrochem, self).get_context_data(**kwargs)
		context['pet_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Petrochem')
		
		return context

class Issue_Solar(ListView):
	model = Issue_index
	template_name = 'Issue/Energy/Industry_Solar.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Solar, self).get_context_data(**kwargs)
		context['sol_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Solar')
		
		return context

class Issue_Utilities(ListView):
	model = Issue_index
	template_name = 'Issue/Energy/Industry_Utilities.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Utilities, self).get_context_data(**kwargs)
		context['uti_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Utilities')
		
		return context

class Issue_Financial(ListView):
	model = Issue_index
	template_name = 'Issue/Industry_Financial.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Financial, self).get_context_data(**kwargs)
		context['fin_industry'] = Issue_index.objects.filter(company__second_industry_name__parent__first_name = 'Financials')
		
		return context

class Issue_Bank(ListView):
	model = Issue_index
	template_name = 'Issue/Financial/Industry_Bank.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Bank, self).get_context_data(**kwargs)
		context['ban_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Bank')
		
		return context

class Issue_Securities(ListView):
	model = Issue_index
	template_name = 'Issue/Financial/Industry_Securities.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Securities, self).get_context_data(**kwargs)
		context['sec_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Securities')
		
		return context

class Issue_Insurance(ListView):
	model = Issue_index
	template_name = 'Issue/Financial/Industry_Insurance.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Insurance, self).get_context_data(**kwargs)
		context['ins_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Insurance')
		
		return context

class Issue_Other_Financial_Service(ListView):
	model = Issue_index
	template_name = 'Issue/Financial/Industry_Other_Financial_Service.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Other_Financial_Service, self).get_context_data(**kwargs)
		context['ofs_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Other_Financial_Service')
		
		return context

class Issue_Healthcare(ListView):
	model = Issue_index
	template_name = 'Issue/Industry_Healthcare.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Healthcare, self).get_context_data(**kwargs)
		context['hea_industry'] = Issue_index.objects.filter(company__second_industry_name__parent__first_name = 'Healthcare')
		
		return context

class Issue_Medical_equipment(ListView):
	model = Issue_index
	template_name = 'Issue/Healthcare/Industry_Medical_equipment.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Medical_equipment, self).get_context_data(**kwargs)
		context['med_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Medical_equipment')
		
		return context

class Issue_Pharmaceuticals(ListView):
	model = Issue_index
	template_name = 'Issue/Healthcare/Industry_Pharmaceuticals.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Pharmaceuticals, self).get_context_data(**kwargs)
		context['pha_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Pharmaceuticals')
		
		return context

class Issue_Biotech(ListView):
	model = Issue_index
	template_name = 'Issue/Healthcare/Industry_Biotech.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Biotech, self).get_context_data(**kwargs)
		context['bio_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Biotech')
		
		return context

class Issue_Idustrials(ListView):
	model = Issue_index
	template_name = 'Issue/Industry_Industrials.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Idustrials, self).get_context_data(**kwargs)
		context['idu_industry'] = Issue_index.objects.filter(company__second_industry_name__parent__first_name = 'Idustrials')
		
		return context

class Issue_Plant(ListView):
	model = Issue_index
	template_name = 'Issue/Industrials/Industry_Plant.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Plant, self).get_context_data(**kwargs)
		context['pla_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Plant')
		
		return context

class Issue_Shipbuilding(ListView):
	model = Issue_index
	template_name = 'Issue/Industrials/Industry_Shipbuilding.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Shipbuilding, self).get_context_data(**kwargs)
		context['shi_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Shipbuilding')
		
		return context

class Issue_Materials(ListView):
	model = Issue_index
	template_name = 'Issue/Industry_Materials.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Materials, self).get_context_data(**kwargs)
		context['mat_industry'] = Issue_index.objects.filter(company__second_industry_name__parent__first_name = 'Materials')
		
		return context

class Issue_Construction(ListView):
	model = Issue_index
	template_name = 'Issue/Materials/Industry_Construction.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Construction, self).get_context_data(**kwargs)
		context['con_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Construction')
		
		return context

class Issue_Steel(ListView):
	model = Issue_index
	template_name = 'Issue/Materials/Industry_Steel.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Steel, self).get_context_data(**kwargs)
		context['ste_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Steel')
		
		return context

class Issue_Chemical(ListView):
	model = Issue_index
	template_name = 'Issue/Materials/Industry_Chemical.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Chemical, self).get_context_data(**kwargs)
		context['che_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Chemical')
		
		return context

class Issue_Other(ListView):
	model = Issue_index
	template_name = 'Issue/Industry_Other.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Other, self).get_context_data(**kwargs)
		context['oth_industry'] = Issue_index.objects.filter(company__second_industry_name__parent__first_name = 'Other')
		
		return context

class Issue_Conglomerates_Holdco(ListView):
	model = Issue_index
	template_name = 'Issue/Other/Industry_Conglomerates_Holdco.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Conglomerates_Holdco, self).get_context_data(**kwargs)
		context['con_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Conglomerates_Holdco')
		
		return context

class Issue_Trading(ListView):
	model = Issue_index
	template_name = 'Issue/Other/Industry_Trading.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Trading, self).get_context_data(**kwargs)
		context['tra_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Trading')
		
		return context

class Issue_Other_other(ListView):
	model = Issue_index
	template_name = 'Issue/Other/Industry_Other_other.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Other_other, self).get_context_data(**kwargs)
		context['oth_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Other')
		
		return context

class Issue_Tech(ListView):
	model = Issue_index
	template_name = 'Issue/Industry_Tech.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Tech, self).get_context_data(**kwargs)
		context['tec_industry'] = Issue_index.objects.filter(company__second_industry_name__parent__first_name = 'Tech')
		
		return context

class Issue_E_commerce(ListView):
	model = Issue_index
	template_name = 'Issue/Tech/Industry_E_commerce.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_E_commerce, self).get_context_data(**kwargs)
		context['eco_industry'] = Issue_index.objects.filter(company__second_industry_name__parent__first_name = 'E_commerce')
		
		return context

class Issue_IT(ListView):
	model = Issue_index
	template_name = 'Issue/Tech/Industry_IT.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_IT, self).get_context_data(**kwargs)
		context['it_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'IT')
		
		return context

class Issue_Machinery(ListView):
	model = Issue_index
	template_name = 'Issue/Tech/Industry_Machinery.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Machinery, self).get_context_data(**kwargs)
		context['mac_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Machinery')
		
		return context

class Issue_Semiconductor(ListView):
	model = Issue_index
	template_name = 'Issue/Tech/Industry_Semiconductor.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Semiconductor, self).get_context_data(**kwargs)
		context['sem_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Semiconductor')
		
		return context

class Issue_Display(ListView):
	model = Issue_index
	template_name = 'Issue/Tech/Industry_Display.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Display, self).get_context_data(**kwargs)
		context['dis_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Display')
		
		return context

class Issue_Internet_Service(ListView):
	model = Issue_index
	template_name = 'Issue/Tech/Industry_Internet_Service.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Internet_Service, self).get_context_data(**kwargs)
		context['int_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Internet_Service')
		
		return context

class Issue_Software(ListView):
	model = Issue_index
	template_name = 'Issue/Tech/Industry_Software.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Software, self).get_context_data(**kwargs)
		context['sof_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Software')
		
		return context

class Issue_Tech_other(ListView):
	model = Issue_index
	template_name = 'Issue/Tech/Industry_Tech_other.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Tech_other, self).get_context_data(**kwargs)
		context['oth_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Tech_other')
		
		return context

class Issue_Telecom(ListView):
	model = Issue_index
	template_name = 'Issue/Industry_Telecom.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Telecom, self).get_context_data(**kwargs)
		context['tel_industry'] = Issue_index.objects.filter(company__second_industry_name__parent__first_name = 'Telecom')
		
		return context

class Issue_Telecom_Service(ListView):
	model = Issue_index
	template_name = 'Issue/Telecom/Industry_Telecom_Service.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Telecom_Service, self).get_context_data(**kwargs)
		context['ser_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Telecom_Service')
		
		return context

class Issue_Telecom_Equipment(ListView):
	model = Issue_index
	template_name = 'Issue/Telecom/Industry_Telecom_Equipment.html'

	def get_context_data(self, **kwargs):
		context = super(Issue_Telecom_Equipment, self).get_context_data(**kwargs)
		context['tel_industry'] = Issue_index.objects.filter(company__second_industry_name__second_name = 'Telecom_Equipment')
		
		return context
						
