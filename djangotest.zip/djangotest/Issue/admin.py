from django.contrib import admin
from .models import Issue_index

# Register your models here.

class IndexAdmin(admin.ModelAdmin):
	list_display = ('title', 'company' )

admin.site.register(Issue_index,IndexAdmin)
