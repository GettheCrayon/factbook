#from __future__ import unicode_literals
#from ckeditor_uploader.widgets import CKEditorUploadingWidget
#from django import forms
#from .models import Post


#class MyForm(forms.ModelForm):
#	title = forms.CharField(required=True)
#	text = forms.CharField(widget=CKEditorUploadingWidget())
#
#	class Meta:
#	   model = Post
#	   fields = ('title', 'text')

