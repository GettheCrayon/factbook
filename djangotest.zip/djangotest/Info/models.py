from django.db import models
from django.core.urlresolvers import reverse

# Create your models here.

class first_industry_name(models.Model):
	first_name = models.CharField(max_length = 50)
	description = models.CharField('One Line Description', max_length=100, blank=True)
	
	class Meta:
		ordering = ['first_name']

	def __str__(self):
		return self.first_name

	def get_absolute_url(self):
		return reverse('Info:industry_name_detail', args=(self.id,))

class second_industry_name(models.Model):
	second_name = models.CharField(max_length = 50)
	description = models.CharField('One Line Description', max_length=100, blank=True)
	parent = models.ForeignKey(first_industry_name) 

	class Meta:
		ordering = ['second_name']

	def __str__(self):
		return self.second_name

	def get_absolute_url(self):
		return reverse('Info:industry_name_detail', args=(self.id,))

class company_name(models.Model):	
	title = models.CharField(max_length=50)
	second_industry_name = models.ForeignKey(second_industry_name)
	description = models.TextField('One Line Description', blank=True)

	class Meta:
		ordering = ['title']
 
	def __str__(self):
		return self.title

	def get_absolute_url(self):
		return reverse('Info:company_name_detail', args=(self.id,))

#parent = models.ForeignKey('self', null=True, blank=True) 


	
