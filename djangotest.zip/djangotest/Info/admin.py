from django.contrib import admin
from Info.models import company_name, first_industry_name, second_industry_name
# Register your models here.

class companyInline(admin.StackedInline):
	model = company_name

class firstindustryAdmin(admin.ModelAdmin):
	list_display = ('first_name', 'description')

class secondindustryAdmin(admin.ModelAdmin):
	inlines = [companyInline]
	list_display = ('second_name', 'description', 'parent')

class companyAdmin(admin.ModelAdmin):
	list_display = ('title', 'second_industry_name')

admin.site.register(first_industry_name, firstindustryAdmin)
admin.site.register(second_industry_name, secondindustryAdmin)
admin.site.register(company_name,companyAdmin)
