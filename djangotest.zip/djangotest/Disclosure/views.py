from django.shortcuts import render
from Disclosure.models import disclosure_index
from django.views.generic.edit import FormView
from django.db.models import Q
from .forms import PostSearchForm

# Create your views here.

class disclosure_home(FormView):
	model = disclosure_index
	form_class = PostSearchForm
	template_name = 'Disclosure/Disclosure_home.html'

	def get_context_data(self, **kwargs):
		context = super(disclosure_home, self).get_context_data(**kwargs)
		context['samsung'] = disclosure_index.objects.filter(company__title = 'samsung')
		
		return context
	
	def form_valid(self, form):	
		schWord = '%s' % self.request.POST['search_word']
		ind_post_list = Issue_index.objects.filter(Q(company__title__icontains=schWord)).distinct()
		dis_post_list = disclosure_index.objects.filter(Q(company__title__icontains=schWord)).distinct()
		ana_post_list = analyst_index.objects.filter(Q(company__title__icontains=schWord)).distinct()
		context = {}
		context['form'] = form
		context['search_term'] = schWord
		context['ind_object_list'] = ind_post_list
		context['dis_object_list'] = dis_post_list
		context['ana_object_list'] = ana_post_list

		return render(self.request,'search.html', context)


class disclosure_more(FormView):
	model = disclosure_index
	form_class = PostSearchForm
	template_name = 'Disclosure/Disclosure_more.html'
	
	def get_context_data(self, **kwargs):
		context = super(disclosure_more, self).get_context_data(**kwargs)
		context['all_disclosrue'] = disclosure_index.objects.all()
		#context['sch_disclosure'] = disclosure_index.objects.filter(company__title = post)
		
		return context

	def form_valid(self, form):	
		schWord = '%s' % self.request.POST['search_word']
		ind_post_list = Issue_index.objects.filter(Q(company__title__icontains=schWord)).distinct()
		dis_post_list = disclosure_index.objects.filter(Q(company__title__icontains=schWord)).distinct()
		ana_post_list = analyst_index.objects.filter(Q(company__title__icontains=schWord)).distinct()
		context = {}
		context['form'] = form
		context['search_term'] = schWord
		context['ind_object_list'] = ind_post_list
		context['dis_object_list'] = dis_post_list
		context['ana_object_list'] = ana_post_list

		return render(self.request,'search.html', context)




#	def form_redirect(request,pk):
#		if request.method == "GET":
#			if request.id == "result_ind_more":
#				form = PostSearchForm(request.POST)
#				if form.is_valid():
#					post = form.save(commit=False)
#					post.save()
#					return redirect('Issue/Industry_Analysis_more.html', pk=post.pk)
#			elif request.id == "result_dis_more":
#				form = PostSearchForm(request.POST)
#				if form.is_valid():
#					post = form.save(commit=False)
#					post.save()
#					return redirect('Disclosure/Disclosure_more.html', pk=post.pk)
#			elif request.id == "result_ana_more":
#				form = PostSearchForm(request.POST)
#				if form.is_valid():
#					post = form.save(commit=False)
#					post.save()
#					return redirect('Analyst/Analyst_more.html', pk=post.pk)

