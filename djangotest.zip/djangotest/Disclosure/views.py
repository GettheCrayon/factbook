from django.shortcuts import render
from django.views.generic import ListView
from Disclosure.models import disclosure_index

# Create your views here.

class disclosure_home(ListView):
	model = disclosure_index
	template_name = 'Disclosure/Disclosure_home.html'

	def get_context_data(self, **kwargs):
		context = super(disclosure_home, self).get_context_data(**kwargs)
		context['samsung'] = disclosure_index.objects.filter(company__title = 'samsung')
		
		return context

