from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.disclosure_home.as_view(), name='disclosure_home'),

]
