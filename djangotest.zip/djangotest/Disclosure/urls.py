from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.disclosure_home.as_view(), name='disclosure_home'),
    url(r'^Disclosure_more/', views.disclosure_more.as_view(), name='more'),
]
