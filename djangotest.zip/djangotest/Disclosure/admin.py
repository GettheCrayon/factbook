from django.contrib import admin
from .models import disclosure_index

# Register your models here.

class IndexAdmin(admin.ModelAdmin):
	list_display = ('title', 'company' )

admin.site.register(disclosure_index,IndexAdmin)
