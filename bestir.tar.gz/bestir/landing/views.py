from django.shortcuts import render
from django.views.generic.base import TemplateView
from django.views.generic.edit import CreateView
from landing.models import Post
from django.core.urlresolvers import reverse_lazy 

# Create your views here.

class home(TemplateView):

	template_name = 'home.html'

class Annual_report(TemplateView):
	template_name = 'Annual_report.html'

class IR_service(TemplateView):
	template_name = 'ir_service.html'

class iss(TemplateView):
	template_name = 'iss.html'

class iro(TemplateView):
	template_name = 'iro.html'

class ipo(TemplateView):
	template_name = 'ipo.html'

class contact(CreateView):
	model = Post
	template_name = 'contact.html'
	fields = ['name', 'email', 'title', 'message']

	def get_success_url(self):
		return reverse_lazy('landing:home')
	
