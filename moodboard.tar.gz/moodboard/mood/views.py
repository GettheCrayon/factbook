#from django.shortcuts import render
from django.views.generic import CreateView, TemplateView
from .models import Picture, Project, URLData
from django.utils import timezone
from .response import JSONResponse, response_mimetype
from django.core.urlresolvers import reverse_lazy
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render


class PictureCreateView(CreateView):
	model = Picture
	template_name = "moodboard/picture_form.html"
	fields = ['file', 'proj']

	def form_valid(self, form):
		self.object = form.save()
		print(self.object)
		data = {'status': 'success'}
		response = JSONResponse(data, mimetype=response_mimetype(self.request))
		print(response)
		return response

	def get_context_data(self, **kwargs):
		context = super(PictureCreateView, self).get_context_data(**kwargs)
		context['Pro_view'] = Project.objects.get(name=self.kwargs['slug'])
		
		return context

class ProjectIndex(TemplateView):
	model = Project
	template_name = "moodboard/Project_index.html"

	def get_context_data(self, **kwargs):
		context = super(ProjectIndex, self).get_context_data(**kwargs)
		context['Pro_all'] = Project.objects.filter(publish_date__lte=timezone.now()).order_by('publish_date')
		
		return context

class ProjectCreateView(CreateView):
	model = Project
	fields = ['name']
	template_name = "moodboard/Project_create.html"
	success_url = reverse_lazy('Project:index')

class ProjectView(TemplateView):
	model = Project
	template_name = "moodboard/Project_view.html"

	def get_context_data(self, **kwargs):
		context = super(ProjectView, self).get_context_data(**kwargs)
		context['Pro_view'] = Project.objects.get(name=self.kwargs['slug'])
		
		return context

@csrf_exempt
def DoWriteBoard(request):
	context={}
	br = URLData(title = request.POST['title'],
		link = request.POST['link'],
		tag = request.POST['tag'],
		)
	br.save()

	context['Pro_all'] = Project.objects.filter(publish_date__lte=timezone.now()).order_by('publish_date')
    
    # 다시 조회    
	return render(request, 'moodboard/Project_index.html', context)
                   

