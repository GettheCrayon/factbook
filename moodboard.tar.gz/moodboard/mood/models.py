from django.db import models
from django.template.defaultfilters import slugify
from django.utils import timezone
import datetime
from tagging.fields import TagField
from bs4 import BeautifulSoup
import requests

class Project(models.Model):
	name = models.CharField(max_length=30)
	slug = models.SlugField(blank=True)
	publish_date = models.DateTimeField(default=timezone.now)

	TYPE_CHOICES =(
				('business scope', 'Business Scope'),
				('history', 'History'),
				('change in capital', 'Change in Capital'),
				('share with voting right', 'Share with Voting Right'),
				('dividend', 'Dividend'),
			)
	project_type = models.CharField(max_length = 15, choices=TYPE_CHOICES, default='A')
	project_field = models.CharField(max_length = 50)
	project_co = models.CharField(max_length = 20)
	
	start_date = models.DateTimeField(null=True)
	end_date = models.DateTimeField(null=True)

	TOOL_CHOICES = (
				('business scope', 'Business Scope'),
				('history', 'History'),
				('change in capital', 'Change in Capital'),
				('share with voting right', 'Share with Voting Right'),
				('dividend', 'Dividend'),
		)

	project_tool = models.CharField(max_length = 15, choices=TOOL_CHOICES, default='A')

	description = models.TextField(blank=True)
	project_result = models.TextField(blank=True)

	def publish(self, *args, **kwargs):
		self.publish_date = datetime.timezone.now()
		return super(Project, self).save(*args, **kwargs)

	def save(self, *args, **kwargs):
		if not self.id:
		# Newly created object, so set slug
			self.slug = slugify(self.name)

		super(Project, self).save(*args, **kwargs)

class Picture(models.Model):
	proj = models.ForeignKey(Project)
	"""
	This is a small demo using just two fields. ImageField depends on PIL or
	pillow (where Pillow is easily installable in a virtualenv. If you have
	problems installing pillow, use a more generic FileField instead.
	"""

	file = models.ImageField(upload_to="pictures")

	def __unicode__(self):
		return self.file.name


class URLData(models.Model):
	title = models.CharField(max_length=200)
	link = models.URLField()
	tag = TagField()
	image = models.ImageField(blank=True , default='media/images.jpeg')

	def save(self, *args, **kwargs):
		if self.link:
			soup = BeautifulSoup(requests.get(self.link).content, "lxml")
			if soup.title.string and not self.title: #title tag 문자 가져옴
				self.title = soup.title.string
			meta = soup.find_all('meta')
		
			if soup.find(property = "og:image"):  #페이스북 open graph
				image = soup.find(property = "og:image").get('content')
				self.image = image
			elif soup.find(property = "twitter:image"): #트위터 open graph
				image = soup.find(property = "twitter:image").get('content')
				self.image = image
			elif soup.find_all('img')[0]: #둘다 없을 시 이미지 아무거나 때옴
				self.image = soup.find_all('img')[0].get('src')

			#다 없으면 디폴트 이미지로 들어감

		super(URLData, self).save(*args, **kwargs)	
