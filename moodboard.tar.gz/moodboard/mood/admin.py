from mood.models import Picture, Project
from .models import URLData
from django.contrib import admin

class PictureAdmin(admin.ModelAdmin):
	list_display = ('__unicode__','proj')

class ProjectAdmin(admin.ModelAdmin):
	list_display = ('name','publish_date')

admin.site.register(URLData)
admin.site.register(Picture, PictureAdmin)
admin.site.register(Project, ProjectAdmin)
