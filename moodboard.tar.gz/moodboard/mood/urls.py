from django.conf.urls import url
from . import views

urlpatterns = [
	url(r'^$', views.ProjectIndex.as_view(), name='index'),
	url(r'^add/$', views.ProjectCreateView.as_view(), name='create_pro'),
	url(r'^DoWriteBoard/$', views.DoWriteBoard),
	url(r'^(?P<slug>[\w\-]+)/$', views.PictureCreateView.as_view(), name='create_pic'),
]
