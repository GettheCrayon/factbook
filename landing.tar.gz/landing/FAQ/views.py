from django.shortcuts import render
from django.views.generic.edit import CreateView
from FAQ.models import Question

# Create your views here.

class Landing(CreateView):
	model = Question
	template_name = 'FAQ/Landing.html'
	fields = ['direction', 'wanted_comment', 'contact']
	
	def get_success_url(self):
		return reverse_lazy('faq:new')
