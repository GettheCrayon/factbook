from django.apps import AppConfig


class FaqConfig(AppConfig):
    name = 'FAQ'
