import decimal
from urllib.parse import urlencode
from urllib.request import urlopen
import urllib.request, urllib.parse, urllib.error
import sys

from django.conf import settings

from factbook.models import *

class Verify( object ):
	def __init__(self, tx):
		try:
			transaction = factbook_Purchase.objects.get( tx =tx )
			self.result = 'Transaction %s has already been processed' % tx
			self.response = self.result
		except factbook_Purchase.DoesNotExist:
			post = dict()
			post[ 'cmd' ] = '_notify-synch'
			post[ 'tx' ] = tx
			post[ 'at' ] = settings.PAYPAL_PDT_TOKEN
			aaa = urlencode(post)
			aaa = aaa.encode('utf-8')
			self.response = urlopen(settings.PAYPAL_PDT_URL,aaa).read()
			bbb = self.response
			lines = bbb.decode().split('\n')
			self.result = lines[0].strip()
			self.results = dict()
			for line in lines[1:]:
				linesplit = line.split('=',2)
				if len(linesplit) ==2:
					self.results[ linesplit[0].strip() ] = urllib.parse.unquote(linesplit[1].strip())

	def success( self ):
		return self.result == 'SUCCESS' and self.results[ 'payment_status' ] == 'Completed'

	def amount( self ):
		return decimal.Decimal(self.results['payment_gross'])


