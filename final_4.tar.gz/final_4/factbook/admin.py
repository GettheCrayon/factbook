from django.contrib import admin
from .models import Post, factbook_document

#class companyInline(admin.StackedInline):
	#model = Post

class PostAdmin(admin.ModelAdmin):
	#inlines = [companyInline]
	list_display = ('company','category','created_date', 'id')

class documentAdmin(admin.ModelAdmin):
	list_display = ('company','location','price')

admin.site.register(Post,PostAdmin)
admin.site.register(factbook_document,documentAdmin)

# Register your models here.




